import socket
import sys
from _thread import *


max_conn = 5  # Max connection queues to hold
buffer_size = 4096  # Max socket buffer size
listening_port = 8080  # Port to listen from

def start():
    # Start up socket and listen for connections
    # If incoming connection: Start process for potentially modify data
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Initialize socket
        s.bind(('', listening_port))  # Bind socket for listening
        s.listen(max_conn)  # Start listening for incoming connections
        print("*** Server Started Successfully [ %d ]\n" % listening_port)
    except Exception as e:
        # Execute this block if socket anything fails
        print("*** Unable To Initialize Socket")
        sys.exit(2)

    while 1:
        try:
            conn, addr = s.accept()  # Accept connection from client browser
            data = conn.recv(buffer_size)  # Receive client data
            start_new_thread(conn_string, (conn, data))  # Start a thread
        except KeyboardInterrupt:
            # Execute this block if client socket failed
            s.close()
            print("\n*** Socket failed")
            sys.exit(1)


def conn_string(conn, data):
    # Decode request and collect/define necessary data to send to server
    try:
        data2 = data.decode("utf-8")
        first_line = data2.split('\n')[0]
        url = first_line.split(' ')[1]
        http_pos = url.find("://")

        # Getting URL
        if http_pos == -1:
            temp = url
        else:
            temp = url[(http_pos + 3):]

        port_pos = temp.find(":")
        webserver_pos = temp.find("/")

        if webserver_pos == -1:
            webserver_pos = len(temp)

        # If no port is specified, set default port
        if port_pos == -1 or webserver_pos < port_pos:
            port = 80
            webserver = temp[:webserver_pos]
        else:
            # If specific port
            port = int((temp[(port_pos + 1):])[:webserver_pos - port_pos - 1])
            webserver = temp[:port_pos]

        proxy_server(webserver, port, conn, data)

    except Exception as e:
        pass


def proxy_server(webserver, port, conn, data):
    # Send request to server and then modify return data
    # before sending it back to browser

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((webserver, port))
        s.send(data)

        while 1:

            reply = s.recv(buffer_size)
            if len(reply) > 0:
                # Modify data
                reply = reply.replace(b' Stockholm', b' Linkoping')
                reply = reply.replace(b'Smiley', b'Trolly')
                reply = reply.replace(b'./smiley.jpg',
                                      b'http://zebroid.ida.liu.se/fakenews/trolly.jpg')
                conn.send(reply)  # Send modified reply to browser

                print("*** Request succeeded!")
            else:
                # Break the connection if receiving data failed
                break

        s.close()
        conn.close()
    except socket.error as e:
        s.close()
        conn.close()
        sys.exit(1)


start()
